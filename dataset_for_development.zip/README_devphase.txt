This year's machine learning competition sees how well you can automate the "ideal" job candidate across different jobs.

For the development phase, you have a variety of organizations seeking to fill 50 jobs. Each job has a unique job title, which will make it easier to refer to when you are completing your spreadsheet.

For the test phase, you will have over 200 jobs to complete, so make sure that your approach is scalable enough to use during the 7-day test phase period.

########dev_companies_jobs_and_ads.xlsx 

Information on these companies and jobs is found is the dev_companies_jobs_and_ads.xlsx spreadsheet. This spreadsheet contains the following columns:

- Company: Name of Organization Hiring

- Mission: A brief statement of the organization

- Products: What the organization sells or develops

- Annual Revenue in Billions: Revenue
Employee Count: Total number of employees in organization

- Role Title: Specific title of the position provided by the organization
Department: Where the position is located in the organization

- Department Function: Basic description of the role's function within the department
Advertisement: A recruiting statement containing a description of the organization, role title, and what the role title would do within the organization

########dev_jobapplication.xlsx 
After familiarizing yourself with the different organizations and jobs, your goal is to complete the dev_applicant_responses.xlsx sheet using some type of computer-mediated approach.

There are five columns in that sheet. You must completely fill out the last column (no empty cells)
- Job: The role title from dev_companies_jobs_and_ads.xlsx
- Question: What specific selection question must the applicant answer
- Format: How must the answer to the selection question be structured. This is typically a type (integer, number, text) and a range those values can take (1 to 5,-2 to 2, max 750 characters)
- Item: What is a shorthand way you can refer to the question or theme of questions asked
- Response: What is the applicant's answer to the question. This is the key column that you must optimize.


When you have completely filled in a sheet, you can submit it at: https://computationaloutreach.com/siopmlcompetition/submit.html

Do not leave any blanks or the scoring script will either have an error or fill in with random values
You can make up to 30 submissions a day for dev data until the competition ends 3/16/2025

The test phase will begin 3/9/2025, and you will have 7 days to make your final submissions. You have a total of 5 test submissions available.

There is also an optional API endpoint available at:
https://computationaloutreach.com/siopmlcompetition/api.php

To use the API endpoint, send a POST requested containing your complete excel sheet in files, and pass along your token and the phase ("dev" or "test") as token and phase parameters in the POST data.

########dev_jobapplication_completedexample.xlsx
To make sure you are able to use the submission interface, we provide an example completed form:
dev_jobapplication_completedexample.xlsx

Your approach should generalize across all jobs, and so you will receive a score across the entire application file.

You can view your submissions at: https://computationaloutreach.com/siopmlcompetition/submissions.php

Your relative performance to other teams will be displayed at:
https://computationaloutreach.com/siopmlcompetition/leaderboard.html

If you have questions please contact ivanhernandez@vt.edu







